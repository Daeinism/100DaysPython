from replit import clear
import art

# def addBidder(bidName, bidAmount):
    
#HINT: You can call clear() to clear the output in the console.

print(art.logo)
print("Welcome to the secret auction program.")

bids = {}

moreBidder = True

while moreBidder:
    name = input("What is your name?: ")
    price = int(input("What's your bid? $"))
    
    bids[name] = price

    answer = input("Are there any other bidders? Type 'yes' or 'no'.\n")
    if answer == "no" or answer != "yes":
        moreBidder = False
    else:
        clear()

highestBid = 0
highestBidder = ""
for eachPerson in bids:
    if bids[eachPerson] > highestBid:
        highestBid = bids[eachPerson]
        highestBidder = eachPerson
        
print(f"The winner is {highestBidder} with a bid of ${highestBid}.")
