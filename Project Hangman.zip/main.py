import random
import art
import words
from replit import clear

lives = 6
word = random.choice(words.wordList)

print(art.logo)
print(f"pssst. The word is {word}")

display = []
for letter in word:
    display += '_'

gameEnd = False

while not gameEnd:
    guess = input("Guess a letter: ").lower()

    clear()
    
    if guess not in word:
        print(f"\nYou guessed {guess}, that is not in the word!")
        lives -= 1
    elif guess in display:
        print("\nYou've already used that letter!")
    
    for num in range(len(word)):
        if word[num] == guess:
            display[num] = guess 

    print(f"{''.join(display)}")
    print(art.stages[lives])
  
    if lives == 0 :
        gameEnd = True
        print("You Lose")
    elif "_" not in display:
        gameEnd = True
        print("You Win")